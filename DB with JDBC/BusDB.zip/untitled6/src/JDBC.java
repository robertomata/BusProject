import java.sql.*;

public class JDBC {
    public static void main(String[] args) throws SQLException {

        String url = "jdbc:mysql://localhost:3306/demo_afp";
        String user = "root";
        String password = "1qaz2wsx3EDC";

        //1. Connect to database
        Connection dbConnection = DriverManager.getConnection(url, user, password);

        //2. Create a statement
        Statement firstStatement = dbConnection.createStatement();

        //2.5 prepared statement, why? makes it easier to prepare statements, prevents sql injection attacks and is
        //precompiled position are 1 based , left to right

        //3. execute sql statement
        String sqlSelectQuery = "SELECT * FROM nba_players";
        ResultSet listOfNBAPlayers = firstStatement.executeQuery(sqlSelectQuery);

        //4. Print results

        while(listOfNBAPlayers.next()){
            System.out.println(listOfNBAPlayers.getString(1) + " " + listOfNBAPlayers.getString(2)
                    + " " + (listOfNBAPlayers.getString(3)));

        }
        String selectPreparedStatement = "SELECT ? FROM nba_players";


        //5. method




    }
}