package com.company;

import org.w3c.dom.ls.LSOutput;

import javax.swing.plaf.nimbus.State;
import java.sql.*;

public class BusDB {
    public static void main(String[] args) throws SQLException {
        String url = "jdbc:mysql://localhost:3306/busdb";
        String user = "Bus_Sys_Admin";
        String password = "adminPassword";

        Connection dbConnection = DriverManager.getConnection(url, user, password);
        Statement commandStatement = dbConnection.createStatement();


     /*  //create bus //working
        Integer model_nr = 12345;
        Integer capacity = 40;
        int newBus = InsertBus(dbConnection, model_nr, capacity);*/

        //create route
      /*  String start_stop = "Oslo";
        String end_stop = "Bergen";
        int expected_time =  5;
        int newRoute = InsertRoute (dbConnection, start_stop, end_stop, expected_time);*/
/*
        //create trip
        String trip_name = "First Trip";
        String trip_date = "21.01.07";
        Integer bus_id = 1;
        Integer route_id = 1;
        int firstTrip = InsertTrip(dbConnection, trip_name, trip_date, bus_id, route_id);
        */

       /* //create passenger
        String first_name = "John";
        String last_name  = "Lock";
        int firstPassenger = newPassenger(dbConnection, first_name, last_name);

        //create trip_passenger
        int trip_id = 1;
        int passenger_id = 2;
        String seat_type = "Window";
        int newTripPassenger = addTripPassenger(dbConnection,trip_id,passenger_id,seat_type);



      //print route
       printData(dbConnection);


       //print passenger list
       String name = "Oslo - Trondheim";
       printPassenger(dbConnection, name);


        //updatePassenger info
        int passenger_id = 1;
        String first_name = "Alfred";
        String last_name = "Hitchcock";
        int updateInfo = updatePassenger(dbConnection, first_name, last_name, passenger_id);

        */

        //deletePassenger info
        int passenger_id = 1;
        deletePassenger(dbConnection, passenger_id);

    }

    /*
            String sqlSelectQuery2 = "SELECT * FROM route";
            ResultSet route = commandStatement.executeQuery(sqlSelectQuery2);

            //prints route information
            while (route.next()) {
                System.out.println("route_id: " + route.getString(1) + " Start: " + route.getString(2)
                        + " Stop: " + (route.getString(3)) + " Time(H): " + route.getString(4));
            }
            //prints trip information
            String sqlSelectQuery3 = "SELECT * FROM trip";
            ResultSet trip = commandStatement.executeQuery(sqlSelectQuery3);

            while (trip.next()){
                System.out.println("TripID: " + trip.getString(1) + " Name: " + trip.getString(2) +
                        " Date: " + trip.getString(3) + " BudID: " + trip.getString(4) +
                        " RouteID: " + trip.getString(5));
            }*/
 //working route bus system, trip
     /*   private static int InsertRoute (Connection dbConnection, String start_stop, String end_stop, int expected_time)
                throws SQLException {
            PreparedStatement newRoute = dbConnection.prepareStatement("INSERT INTO route(start_stop, " +
                        "end_stop, expected_time) VALUES (?, ?, ?)");

            newRoute.setString(1, start_stop);
            newRoute.setString(2, end_stop);
            newRoute.setInt(3, expected_time);

            return newRoute.executeUpdate();
            }*/
/*
      //creates a new BUS
        private static  int InsertBus(Connection dbConnection, int model_nr, int capacity) throws SQLException {
            PreparedStatement newBus = dbConnection.prepareStatement("INSERT INTO bus (model_nr," +
                    " capacity) VALUES( ?, ?)");
            newBus.setInt(1, model_nr);
            newBus.setInt(2, capacity);

            return newBus.executeUpdate();
        }

       private static int InsertTrip (Connection dbConnection, String name, String date, int bus_id,
                                      int route_id) throws SQLException {
            PreparedStatement newTrip = dbConnection.prepareStatement("INSERT INTO trip(name, date, bus_id, " +
                    "route_id) VALUES (?, ?, ?, ?)");

            newTrip.setString(1, name);
            newTrip.setString(2, date);
            newTrip.setInt(3, bus_id);
            newTrip.setInt(4, route_id);

            return newTrip.executeUpdate();
        }*/

       /* private static int newPassenger(Connection dbConnection, String first_name, String last_name) throws SQLException {
            PreparedStatement newPassenger = dbConnection.prepareStatement("INSERT INTO passenger (first_name, last_name)" +
                    "VALUES ( ?, ?)");
            newPassenger.setString(1, first_name);
            newPassenger.setString(2, last_name);

            return newPassenger.executeUpdate();
        }

    //method for booking a trip
    private static int addTripPassenger(Connection dbConnection, Integer trip_id, Integer passenger_id, String seat_type) throws SQLException {
        PreparedStatement addTrip = dbConnection.prepareStatement("INSERT INTO trip_passenger ( trip_id, passenger_id, seat_type)" +
                "VALUES ( ?, ?, ?)");

        addTrip.setInt(1, trip_id);
        addTrip.setInt(2, passenger_id);
        addTrip.setString(3, seat_type);

        return addTrip.executeUpdate();
    }


   private static void printData (Connection dbConnection) throws SQLException {
       Statement commandStatement = dbConnection.createStatement();
       String routeInfo = "SELECT trip.route_id, route.start_stop, route.end_stop, route.expected_time " +
               "FROM trip INNER JOIN route ON trip.route_id = route.route_id";
       ResultSet route = commandStatement.executeQuery(routeInfo);

       //prints route information
       while (route.next()) {

           System.out.println("route_id: " + route.getString(1) + " Start: " + route.getString(2)
                   + " Stop: " + (route.getString(3)) + " Time(H): " + route.getString(4));



   }

    //working printPassenger List, according to trip's name
   private static void printPassenger (Connection dbConnection, String name) throws SQLException{
       PreparedStatement commandStatement = dbConnection.prepareStatement(
       "SELECT trip.name, passenger.first_name, passenger.last_name" +
               " FROM ((passenger JOIN trip_passenger ON passenger.passenger_id = trip_passenger.passenger_id)" +
               " JOIN trip ON trip_passenger.trip_id = trip.trip_id) WHERE name = ?");

       commandStatement.setString(1, name);

       ResultSet passengerList = commandStatement.executeQuery();

       while (passengerList.next()) {
           System.out.println("TRIP: " + passengerList.getString("name")
                   + " NAME: " + passengerList.getString("first_name")
                   + " " + passengerList.getString("last_name"));
       }

   }
*/
    //working delete Passenger
    public static void deletePassenger (Connection dbConnection, int passenger_id) throws SQLException{
        PreparedStatement delPassenger = dbConnection.prepareStatement(
                "DELETE FROM trip_passenger WHERE passenger_id = ?");

        delPassenger.setInt(1, passenger_id);
        delPassenger.executeUpdate();

        PreparedStatement delPassenger2 = dbConnection.prepareStatement("DELETE FROM passenger WHERE passenger_id = ?");

        delPassenger2.setInt(1, passenger_id);
        delPassenger2.executeUpdate();


    }
/*
    //working update passengerInfo
    public static int updatePassenger (Connection dbConnection, String first_name, String last_name, int passenger_id) throws SQLException{

        PreparedStatement updateInfo = dbConnection.prepareStatement("UPDATE passenger " +
                "SET first_name = ?, last_name = ? " +
                "WHERE passenger_id = ?");

        updateInfo.setString(1, first_name);
        updateInfo.setString(2, last_name);
        updateInfo.setInt(3, passenger_id);

        return updateInfo.executeUpdate();
    }
*/




}
